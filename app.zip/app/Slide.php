<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Slide extends Model
{
    protected $table ='slider';


	public static function editSlide($request ,$id ){
	 if($request->img !=""){
        // Upload Image 
        $file                           = $request->img;
        $img                            = date('Y-m-d-H:i:s') . "-" .mt_rand();
        $path                           = 'uploads/projects/';
        $file                           = $file->move($path, $img);
      }
      if($request->img !=""){
      $goal->img      =   $img;
      }
      $goal->save();
	}
}
