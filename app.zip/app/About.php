<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class About extends Model
{
   protected $table ='about_us';

   public static function editAbout($request ,$id){
   	$about          = About::find($id);
   	$about->title   =$request->title ;
   	$about->body    =$request->body;
   	$about->save();

   }
}
