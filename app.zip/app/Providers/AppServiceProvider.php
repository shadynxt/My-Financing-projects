<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\About;
use View; 
use App\Idea;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
          $about_all  = About::all();
        $ideas      =Idea::with('category','city','support')->get();
        View::composer('Site.layouts.master', function($view) use($about_all,$ideas) {
        $view->with('about_all',$about_all)->with('ideas',$ideas);
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
