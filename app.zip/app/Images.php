<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Images extends Model
{


    protected $fillable = ['idea_id' , 'img'];
    protected $table = 'images';



    // public function
}
