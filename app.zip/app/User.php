<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password','facebook_id',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

        //Add User
    public static function addUser($request){
       if($request->profile_pic !=""){
        // Upload Image 
        $file                           = $request->profile_pic;
        $profile_pic                    = date('Y-m-d-H:i:s') . "-" .mt_rand();
        $path                           = 'uploads/projects/';
        $file                           = $file->move($path, $profile_pic);
      }
      
      $user = new User(); 
      $user->token = preg_replace('/[^A-Za-z0-9\-\']/', '', bcrypt(mt_rand()));
      $user->first_name       = $request->first_name;
      $user->last_name        = $request->last_name;
      $user->email            = $request->email;
      $user->phone_number     = $request->phone_number;
      $user->password         = bcrypt($request->password);
      $user->about_you         =$request->about_you;
      $user->link              =$request->link;
      $user->link_facebook     =$request->link_facebook;
      if (!empty(($request->profile_pic))) {
      $user->profile_pic      = $profile_pic;
      }
      $user->city_id          = $request->city_id;
      $user->save();
      return $user;
     }
     
       //Edit User
    public static function editUser($request,$id){
     if($request->profile_pic !=""){
        // Upload Image 
        $file                           = $request->profile_pic;
        $profile_pic                    = date('Y-m-d-H:i:s') . "-" .mt_rand();
        $path                           = 'uploads/projects/';
        $file                           = $file->move($path, $profile_pic);
      }
      $user = User::find($id); 
      $user->first_name       = $request->first_name;
      $user->last_name        = $request->last_name;
      $user->email            = $request->email;
      $user->phone_number     = $request->phone_number;
      if(!empty($request->password)){
      $user->password = bcrypt($request->password);
      }
      $user->about_you         =$request->about_you;
      $user->link              =$request->link;
      $user->link_facebook     =$request->link_facebook;
      if (!empty(($request->profile_pic))) {
      $user->profile_pic     = $profile_pic;
      }
      $user->city_id           = $request->city_id;
      $user->save();
      return $user;
     }

          // all favorites that belongs to this user
     public function favorites()
     {
       return $this->hasMany('App\Favorite');
     }



     // device token
     public function mobile_token()
     {
       return $this->hasMany('App\Mobile_Token');
     }

}
