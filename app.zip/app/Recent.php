<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Auth;
class Recent extends Model
{
    protected $table="recent";

            //Add Comment
    public static function addRecent($request,$id=" "){
      $recent = new Recent(); 
      $recent->body              = $request->body;
      if($id !=""){
      $recent->idea_project_id  = $id;

      }
      $recent->idea_project_id   = $request->idea_project_id;

      if(Auth::id() !=""){
      $recent->user_id   = Auth::id();

      }
      else{
      $recent->user_id           = $request->user_id;

      }
      $recent->save();
     }

     public static function editRecent($request,$id){
      $recent =Recent::find($id);
      $recent->body              = $request->body;
      $recent->idea_project_id   = $request->idea_project_id;
      $recent->user_id           = $request->user_id;
      $recent->save();
     }
}
