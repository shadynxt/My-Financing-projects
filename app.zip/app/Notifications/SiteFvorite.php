<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

class SiteFvorite extends Notification
{
    use Queueable;
    public $favorite;
    public $project;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($favorite)
    {
        $this->favorite =$favorite;
        $this->project  =$favorite->project;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database'];
    }


    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'favorite'       => $this->favorite,
            'project'        => $this->project,
            'userThatNotify' => $notifiable,
            'ownerName'      =>$this->favorite->user->first_name.''.$this->favorite->user->last_name,
        ];

    }
}
